
import './App.css';
import ToDo from './components/screens/ToDo';

function App() {
  return <ToDo />
}

export default App;
